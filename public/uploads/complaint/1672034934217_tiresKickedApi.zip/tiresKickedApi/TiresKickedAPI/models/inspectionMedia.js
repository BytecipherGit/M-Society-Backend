const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const inspectionMediaSchema = new mongoose.Schema({
  genratedInspectionId: {
    type: String,
    require: true,
  },
  inspectionId: {
    type: String,
  },
  mediaType: {
    type: String,
  },
  mediaPath: {
    type: String,
  },
  mediaTitle: {
    type: String,
  },
  mediaDescription: {
    type: String,
  },
  notes: {
    type: String,
  },
  status: {
    type: String,
    enum: ["active", "Inactive"],
    default: "active",
  },
  createdDate: {
    type: Date,
    default: Date.now,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
});

const InspectionMedia = mongoose.model(
  "inspectionMedias",
  inspectionMediaSchema
);

module.exports = InspectionMedia;
