const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const inspectionSchema = new mongoose.Schema({
    genratedInspectionId: {
        type: String,
        require: true,
    },
    userId: {
        type: String
    },
    status: {
        type: String,
        enum: ['active', 'Inactive'],
        default: 'active'
    },
    createdDate: {
        type: Date,
        default: Date.now,
    },
    updatedDate: {
        type: Date,
        default: Date.now,
    },

});

const Inspection = mongoose.model("inspections", inspectionSchema);

module.exports = Inspection;
