const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
  userId: {
    type: String,
    require: true,
  },
  accessToken: {
    type: String,
    require: true,
  },
  refreshToken: {
    type: String,
    require: true,
  },
  deviceType: {
    type: String,
  },
  deviceModel: {
    type: String,
  },
  deviceOs: {
    type: String,
  },
  deviceUniqueId: {
    type: String,
  },
  createdDate: {
    type: Date,
    default: Date.now,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
});

const user_logins = mongoose.model("user_logins", UserSchema);

module.exports = user_logins;
