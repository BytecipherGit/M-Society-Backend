const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    require: true,
  },
  email: {
    type: String,
    unique: true,
  },
  password: {
    type: String,
    require: true,
  },
  status: {
    type: String,
    enum: ["active", "Inactive"],
    default: "Inactive",
  },
  createdDate: {
    type: Date,
    default: Date.now,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  role: {
    type: String,
  },
  phone: {
    type: Number,
    unique: true,
  },
  otp: {
    type: String,
  },
  loginId: {
    type: String,
    unique: true,
  },
  verifyOtp: {
    type: Number,
    enum: ["0", "1"],
    default: "0",
  },
});

const User = mongoose.model("users", UserSchema);

module.exports = User;
