const User = require(".././models/user");
require("dotenv").config();

const jwt = require("jsonwebtoken");
const sgMail = require("@sendgrid/mail");
const UserLogins = require(".././models/user_logins");

exports.validateuser = async (req) => {
  const userToken = req.headers.authorization;
  const token = userToken.split(" ");
  const decoded = jwt.verify(token[1], process.env.ACCESS_TOKEN_SECRET);
  if (decoded.User.loginId) {
    let user = await User.findOne({ loginId: decoded.User.loginId });
    if (!user) {
      let user = await User.findOne({ email: decoded.User.loginId });
      return user;
    }
    return user;
  }
};

exports.sendGrid = async (req, res, payload) => {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  const msg = {
    to: req.body.email,
    from: "noreply@tireskicked.com",
    subject: payload.subject,
    html: payload.html,
  };
  console.log(msg);
  try {
    await sgMail.send(msg);
  } catch (error) {
    console.error(error);

    if (error.response) {
      console.error(error.response.body);
    }
  }
};

exports.headers = async (req, res, requireHeaders) => {
  try {
    var required = {
      userId: requireHeaders.userId,
      deviceType: req.headers.devicetype,
      deviceModel: req.headers.devicemodel,
      deviceOs: req.headers.deviceos,
      deviceUniqueId: req.headers.deviceuniqueid,
      accessToken: requireHeaders.accessToken,
    };
    await UserLogins.create(required);
  } catch (error) {
    console.error(error);

    if (error.response) {
      console.error(error.response.body);
    }
  }
};
