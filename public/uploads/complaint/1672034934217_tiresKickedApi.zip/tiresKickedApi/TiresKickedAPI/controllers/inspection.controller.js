const inspection = require("../models/inspection");
const User = require("../models/user");

//InspectionId genrated
exports.createinspection = async (req, res) => {
    try {
        // genratedinspectionid 
        var genratedInid = "";
        var characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var charactersLength = characters.length;
        for (var i = 0; i < 6; i++) {
            genratedInid += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        let user = await User.find();
        if (user.length==0) {
            await User.create({
                name: "Test",
                email: "test@gmail.com",
                password: "123456"
            }).then(async data => {
                await inspection.create({
                    userId: data._id,
                    genratedInspectionId: genratedInid,
                    status: req.body.status
                }).then(result => {
                    res.status(200).send({
                        success: true,
                        message: "Inspection genrated successfully!",
                        data: result
                    })
                }).catch(err => {
                    res.status(200).send({
                        success: false,
                        message: err.message + "Sorry inspectionId not genrated!",
                        data: {}
                    })
                })
            });
        } else if (user) {
            await inspection.create({
                userId: user[0]._id,
                genratedInspectionId: genratedInid,
                status: req.body.status
            }).then(data => {
                res.status(200).send({
                    success: true,
                    message: "Inspection genrated successfully!",
                    data: data
                })
            }).catch(err => {
                res.status(200).send({
                    success: false,
                    message: err.message + "Sorry inspectionId not genrated!",
                    data: {}
                })
            })
        }
    }
    catch (err) {
        res.status(200).send({
            success: false,
            message: err.message + "Somthink wend wrong",
            data: {}
        })
    }
};