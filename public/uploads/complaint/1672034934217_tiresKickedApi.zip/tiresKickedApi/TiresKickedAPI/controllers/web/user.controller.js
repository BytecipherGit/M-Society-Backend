const User = require("../../models/user");
const UserLogins = require("../../models/user_logins");

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const helper = require("../../helpers/helper");
const { request } = require("express");

exports.singup = async (req, res) => {
  try {
    if (
      !req.body.name ||
      !req.body.email ||
      !req.body.loginId ||
      !req.body.password
    ) {
      return res.status(200).send({
        message: "All fields are mandatory!",
        success: false,
        data: {},
      });
    }
    const userExists = await User.findOne({
      email: req.body.email,
    });
    if (userExists) {
      return res.status(200).send({
        message: "Email is already in use!",
        success: false,
        data: {},
      });
    }

    let password = await bcrypt.hash(req.body.password, 10);
    let otp = Math.floor(1000 + Math.random() * 9000);
    await User.create({
      name: req.body.name,
      phone: req.body.phone,
      loginId: req.body.loginId,
      email: req.body.email,
      password: password,
      otp: otp,
      role: "webUser",
    })

      .then(async (data) => {
        let payload = {
          to: req.body.email,
          subject: " Tireskicked - OTP ",
          html: `Here is your otp: ${otp}`,
        };

        let sendgrid = await helper.sendGrid(req, res, payload);

        return res.status(200).send({
          message: "OTP sent over mail successfully!",
          success: true,
        });
      })
      .catch((err) => {
        console.log(err);
        return res.status(200).send({
          message: "User not added!",
          success: false,
          data: {},
        });
      });
  } catch (err) {
    return res.status(400).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

exports.verifyOTP = async (req, res) => {
  if (!req.body.email || !req.body.otp)
    return res.status(200).send({
      message: "Please provide email & otp!",
      success: false,
      data: {},
    });
  try {
    const user1 = await User.findOne({
      email: req.body.email,
    })

      .then(async (user1) => {
        if (user1.otp == req.body.otp) {
          await User.updateOne(
            { email: req.body.email },
            {
              $set: {
                verifyOtp: 1,
                status: "active",
              },
            }
          );
          const accessToken = generateAccessToken({ user: req.body.email });
          const refreshToken = generateRefreshToken({ user: req.body.email });
          // // implementing headers functionality
          let requireHeaders = {
            userId: user1._id,
            accessToken: accessToken,
          };
          let createlogin = await helper.headers(req, res, requireHeaders);
          const updatedData = await User.findOne({
            email: req.body.email,
          }).select("-password");

          return res.status(200).send({
            message: "OTP is verified!",
            success: true,
            accessToken: accessToken,
            refreshToken: refreshToken,
            data: updatedData,
          });
        } else {
          return res.status(200).send({
            message: "Invalid otp!",
            success: false,
            data: "",
          });
        }
      })
      .catch((err) => {
        return res.status(200).send({
          message: "User doesn`t exists!",
          success: false,
          data: {},
        });
      });
  } catch (err) {
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

// accessTokens functionality
let accessTokens = [];

// accessTokens
function generateAccessToken(User) {
  const accessToken = jwt.sign(User, process.env.ACCESS_TOKEN_SECRET, {
    expiresIn: "1hr",
  });
  accessTokens.push(accessToken);
  return accessToken;
}

// refreshTokens after the access token expires
let refreshTokens = [];

function generateRefreshToken(User) {
  const refreshToken = jwt.sign(User, process.env.REFRESH_TOKEN_SECRET, {
    expiresIn: "60m",
  });
  refreshTokens.push(refreshToken);
  return refreshToken;
}

exports.login = async (req, res) => {
  // if (
  //   !req.headers.devicetype ||
  //   !req.headers.devicemodel ||
  //   !req.headers.deviceos ||
  //   !req.headers.deviceuniqueid
  // ) {
  //   return res.status(200).send({
  //     message: "Please provide headers!",
  //     success: false,
  //     data: {},
  //   });
  // }
  if (!req.body.password || !req.body.loginId) {
    return res.status(200).send({
      message: "please enter Password and loginId!",
      success: false,
      data: {},
    });
  }
  try {
    let user;
    if (req.body.loginId) {
      user = await User.findOne({ loginId: req.body.loginId });
      if (!user) {
        user = await User.findOne({ email: req.body.loginId });
      }
    }

    if (!user) {
      return res.status(200).send({
        message: "user does`t exists!",
        success: false,
        data: {},
      });
    }
    if (user.verifyOtp == "0") {
      return res.status(200).send({
        message: "OTP is not verifed!!",
        success: false,
        data: {},
      });
    } else {
      if (await bcrypt.compare(req.body.password, user.password)) {
        let a = {
          loginId: req.body.loginId,
        };
        let accessToken = generateAccessToken({
          User: a,
        });
        let refreshToken = generateRefreshToken({
          User: a,
        });

        let requireHeaders = {
          userId: user._id,
          accessToken: accessToken,
        };

        let createlogin = await helper.headers(req, res, requireHeaders);

        let userdata = {
          _id: user._id,
          name: user.name,
          status: user.status,
          phone: user.phone,
          email: user.email,
          loginId: user.loginId,
          verifyOtp: user.verifyOtp,
          createdDate: user.createdDate,
          updatedDate: user.updatedDate,
          otp: user.otp,
          __v: 0,
        };

        return res.status(200).send({
          message: "User login successfully!",
          success: true,
          accessToken: accessToken,
          refreshToken: refreshToken,
          data: userdata,
        });
      } else {
        return res.status(200).send({
          message: "Invalid password!",
          success: false,
          data: {},
        });
      }
    }
  } catch (err) {
    console.log(err);
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};
//  forgot password
exports.setNewPassword = async (req, res) => {
  if (
    !req.headers.devicetype ||
    !req.headers.devicemodel ||
    !req.headers.deviceos ||
    !req.headers.deviceuniqueid
  ) {
    return res.status(200).send({
      message: "Please provide headers!",
      success: false,
      data: {},
    });
  }

  try {
    if (!req.body.email || !req.body.otp || !req.body.password)
      return res.status(200).send({
        message: "Please provide mandatory fields!",
        success: false,
        data: {},
      });
    let user1 = await User.findOne({
      email: req.body.email,
    }).then(async (user1) => {
      let password = await bcrypt.hash(req.body.password, 10);
      if (user1.otp == req.body.otp) {
        await User.updateOne(
          { email: req.body.email },
          {
            $set: {
              password: password,
            },
          }
        );
        return res.status(200).send({
          message: "Password changed sucessfully!",
          success: true,
          data: {},
        });
      } else {
        return res.status(200).send({
          message: "Invalid otp!",
          success: false,
          data: "",
        });
      }
    });
  } catch (err) {
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

// send-otp api on email
exports.sendOTP = async (req, res) => {
  if (
    !req.headers.devicetype ||
    !req.headers.devicemodel ||
    !req.headers.deviceos ||
    !req.headers.deviceuniqueid
  ) {
    return res.status(200).send({
      message: "Please provide headers!",
      success: false,
      data: {},
    });
  }
  try {
    if (!req.body.email)
      return res.status(200).send({
        message: "Please provide email!",
        success: false,
        data: {},
      });
    const user = await User.findOne({
      email: req.body.email,
    });

    if (user) {
      let otp = Math.floor(1000 + Math.random() * 9000);

      let payload = {
        to: req.body.email,
        subject: " Tireskicked - OTP ",
        html: `Here is your OTP: ${otp}`,
      };

      let sendgrid = await helper.sendGrid(req, res, payload);
      await User.updateOne(
        { email: req.body.email },
        {
          $set: {
            otp: otp,
          },
        }
      );
      return res.status(200).send({
        message: "OTP sent over mail successfully!",
        success: true,
      });
    } else {
      return res.status(200).send({
        message: "User doesn`t exists!",
        success: false,
        data: {},
      });
    }
  } catch (error) {
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

// chnagePassword after login
exports.changePassword = async (req, res) => {
  let user = await helper.validateuser(req);
  if (
    !req.headers.devicetype ||
    !req.headers.devicemodel ||
    !req.headers.deviceos ||
    !req.headers.deviceuniqueid
  ) {
    return res.status(200).send({
      message: "Please provide headers!",
      success: false,
      data: {},
    });
  }
  var findToken = await UserLogins.findOne({
    accessToken: req.headers.authorization.split(" ")[1],
  });
  if (!findToken) {
    return res.status(200).send({
      message: "Invalid token!",
      success: false,
      data: {},
    });
  }
  try {
    if (!req.body.oldPassword || !req.body.newPassword)
      return res.status(200).send({
        message: "Please provide old & new paasword!",
        success: false,
        data: {},
      });
    if (await bcrypt.compare(req.body.oldPassword, user.password)) {
      let password = await bcrypt.hash(req.body.newPassword, 10);

      await User.updateOne(
        { email: user.email },
        {
          $set: {
            password: password,
          },
        }
      );

      return res.status(200).send({
        message: "Password Changed!",
        success: true,
        data: {},
      });
    } else {
      return res.status(200).send({
        message: "Wrong password entered!",
        success: true,
        data: {},
      });
    }
  } catch (err) {
    return res.status(400).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

// getProfile
exports.getProfile = async (req, res) => {
  const userData = await helper.validateuser(req);
  if (
    !req.headers.devicetype ||
    !req.headers.devicemodel ||
    !req.headers.deviceos ||
    !req.headers.deviceuniqueid
  ) {
    return res.status(200).send({
      message: "Please provide headers!",
      success: false,
      data: {},
    });
  }
  var findToken = await UserLogins.findOne({
    accessToken: req.headers.authorization.split(" ")[1],
  });
  if (!findToken) {
    return res.status(200).send({
      message: "Invalid token!",
      success: false,
      data: {},
    });
  }
  try {
    const profile = await User.findOne({
      // $or: [{ loginId: decoded.User.loginId }, { phone: decoded.User.loginId }],
      _id: userData._id,
    }).select("-password");

    return res.status(200).send({
      message: "Profile data fetched!",
      success: true,
      data: profile,
    });
  } catch (error) {
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

// updateName only
exports.updateProfile = async (req, res) => {
  const userData = await helper.validateuser(req);
  if (
    !req.headers.devicetype ||
    !req.headers.devicemodel ||
    !req.headers.deviceos ||
    !req.headers.deviceuniqueid
  ) {
    return res.status(200).send({
      message: "Please provide headers!",
      success: false,
      data: {},
    });
  }
  var findToken = await UserLogins.findOne({
    accessToken: req.headers.authorization.split(" ")[1],
  });
  if (!findToken) {
    return res.status(200).send({
      message: "Invalid token!",
      success: false,
      data: {},
    });
  }
  try {
    await User.updateOne(
      {
        _id: userData._id,
      },
      {
        $set: {
          name: req.body.name,
        },
      }
    );
    let udatedUser = await User.findOne({ _id: userData._id });
    return res.status(200).send({
      message: "Updated sucessfully",
      success: true,
      data: udatedUser,
    });
  } catch (error) {
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};

exports.logout = async (req, res) => {
  // if (
  //   !req.headers.devicetype ||
  //   !req.headers.devicemodel ||
  //   !req.headers.deviceos ||
  //   !req.headers.deviceuniqueid
  // ) {
  //   return res.status(200).send({
  //     message: "Please provide headers!",
  //     success: false,
  //     data: {},
  //   });
  // }

  try {
    const userData = await helper.validateuser(req);
    var findToken = await UserLogins.findOne({
      accessToken: req.headers.authorization.split(" ")[1],
    });

    if (findToken) {
      await UserLogins.deleteOne({
        accessToken: req.headers.authorization.split(" ")[1],
      });
      return res.status(200).send({
        message: "Logout sucessfully!",
        success: true,
        data: {},
      });
    } else {
      return res.status(200).send({
        message: "Invalid token",
        success: false,
        data: {},
      });
    }
  } catch (error) {
    return res.status(200).send({
      message: "Something went wrong!",
      success: false,
      data: {},
    });
  }
};
