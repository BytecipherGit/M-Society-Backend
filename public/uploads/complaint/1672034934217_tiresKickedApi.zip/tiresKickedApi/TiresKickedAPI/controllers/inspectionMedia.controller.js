const inspectionMedia = require("../models/inspectionMedia");
const inspection = require("../models/inspection");

//Media Create
exports.createInspectionMedia = async (req, res) => {
  try {
    let data = req.body;
    for (let i = 0; i < data.media.length; i++) {
      let mediaDetails = data.media[i];
      await inspectionMedia.create({
        genratedInspectionId: req.body.genratedInspectionId,
        inspectionId: req.body.inspectionId,
        mediaType: mediaDetails.mediaType,
        mediaPath: mediaDetails.mediaPath,
        mediaTitle: mediaDetails.mediaTitle,
        mediaDescription: mediaDetails.mediaDescription,
        notes: mediaDetails.notes,
        status: req.body.status,
      });
    }
    res.status(200).send({
      success: true,
      message: "Submit inspection media successfully!",
      data: {},
    });
  } catch (err) {
    console.log(err);
    res.status(200).send({
      success: false,
      message: err.message + "Somthing went wrong!",
      data: {},
    });
  }
};

// Get inspection media throught inspectionid
exports.get = async (req, res) => {
  try {
    let id = req.params.inspectionId;
    await inspectionMedia
      .find({
        $or: [{ inspectionId: id }, { genratedInspectionId: id }],
      })
      .then((data) => {
        res.status(200).send({
          success: true,
          message: "Media fetch successfully!",
          data: data,
        });
      })
      .catch((err) => {
        res.status(200).send({
          success: false,
          message: err.message + "Media not fetch successfully!",
          data: {},
        });
      });
  } catch (err) {
    res.status(200).send({
      success: false,
      message: err.message + "Somthing went wrong",
      data: {},
    });
  }
};

// Get all inspection medias
exports.getAllInspectionMedia = async (req, res) => {
  var page = parseInt(req.params.page) || 0;
  var limit = parseInt(req.query.limit) || 10;
  var query = {};
  inspectionMedia
    .find(query)
    .sort({ createdDate: -1 })
    .skip(page * limit)
    .limit(limit)
    .exec((err, doc) => {
      if (err) {
        res.status(200).send({
          success: false,
          message: err.message + "Something went wrong!!",
          data: {},
        });
      }

      inspectionMedia.countDocuments(query).exec((count_error, count) => {
        if (err) {
          return res.json(count_error);
        }
        let page1 = count / limit;
        let page2 = Math.round(page1).toFixed(1);
        let page3 = Math.floor(page2);
        console.log(Math.floor(page2));

        return res.status(200).send({
          success: true,
          message: "AllInspectionMedia fetched successfully!",
          inspectionMedia: doc,
          totalPages: page3,
          page: page,
          // pageSize: doc.length,
        });
      });
    });
};

exports.updateMedia = async (req, res) => {
  try {
    let mediaId = req.body.mediaId;

    if (!mediaId) {
      return res.status(200).send({
        success: true,
        message: "Please provide objectId!!",
        data: {},
      });
    }

    let profile = await inspectionMedia.findById(mediaId);

    if (profile) {
      const updated = await inspectionMedia
        .findByIdAndUpdate(
          { _id: mediaId },
          {
            $set: {
              mediaType: req.body.mediaType,
              mediaPath: req.body.mediaPath,
              mediaTitle: req.body.mediaTitle,
              mediaDescription: req.body.mediaDescription,
              notes: req.body.notes,
              status: req.body.status,
            },
          }
        )
        .then((data) => {
          res.status(200).send({
            success: true,
            message: "Updated successfully!!",
            data: {},
          });
        });
    } else {
      res.status(200).send({
        success: false,
        message: err.message + "Please provide a valid objectId!!",
        data: {},
      });
    }
  } catch (err) {
    res.status(200).send({
      success: false,
      message: err.message + "Something went wrong!!",
      data: {},
    });
  }
};

// get all inspections
exports.getAllInspections = async (req, res) => {
  var page = parseInt(req.params.page) || 0;
  var limit = parseInt(req.query.limit) || 10;
  var query = {};
  inspection
    .find(query)
    .sort({ createdDate: -1 })
    .skip(page * limit)
    .limit(limit)
    .exec((err, doc) => {
      if (err) {
        res.status(200).send({
          success: false,
          message: err.message + "Something went wrong!!",
          data: {},
        });
      }

      inspection.countDocuments(query).exec((count_error, count) => {
        if (err) {
          return res.json(count_error);
        }
        let page1 = count / limit;
        let page2 = Math.round(page1).toFixed(1);
        let page3 = Math.floor(page2);

        return res.status(200).send({
          success: true,
          message: "AllInspections fetched successfully!",
          inspection: doc,
          totalPages: page3,
          // page: page,
          // pageSize: doc.length,
        });
      });
    });
};
