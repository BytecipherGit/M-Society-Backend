require("dotenv").config();
const express = require("express");
const app = express();
app.use(express.json());
const jwt = require("jsonwebtoken");
// const port = process.env.PORT;

exports.validateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  if (authHeader) {
    const token = authHeader.split(" ")[1];
    //the request header contains the token "Bearer <token>", split the string and use the second value in the split array.
    if (token == null)
      res.status(400).send({
        message: "Token not present",
        success: false,
        data: {},
      });
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
      if (err) {
        res.status(403).send({
          message: "Token invalid",
          success: false,
          data: {},
        });
      } else {
        req.user = user;
        next();
      }
    });
  } else {
    res.status(400).send({
      message: "Token not present",
      success: false,
      data: {},
    });
  }
};
