const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const mongoose = require("mongoose");
const app = express();
const swaggerJsdoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));
// cors option
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Authorization", "token");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  if (req.method === "OPTIONS") {
    res.header("Access-Control-Allow-Methods", "PUT, POST, DELETE, GET");
    return res.status(200).json({});
  }
  next();
});

// .env Config
require("dotenv").config();

mongoose
  .connect(process.env.mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("MongoDB", err));

require("./routes/inspection.router")(app);
require("./routes/inspectionMedia.router")(app);

require("./routes/web/user.router")(app);
// Swagger implementatation

const options = {
  customCss: ".swagger-ui .topbar { display: bold }",
  definition: {
    openapi: "3.0.0",
    info: {
      title: "tiresKicked Apis with swaggerUi",
      version: "0.1.0",
      description:
        "This is a API documentation for tiresKicked application made with Node and ExpressJs documented with SwaggerUi",
    },
    servers: [
      {
        url: process.env.api_url,
      },
    ],
    components: {
      securitySchemes: {
        apiKeyAuth: {
          type: "apiKey",
          in: "header",
          name: "Authorization",
          bearerFormat: "JWT",
        },
      },
    },
    security: [
      {
        apiKeyAuth: [],
      },
    ],
  },
  // api routes
  apis: ["./routes/web/*.js"],
};

const specs = swaggerJsdoc(options);
app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(specs, { explorer: true })
);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
