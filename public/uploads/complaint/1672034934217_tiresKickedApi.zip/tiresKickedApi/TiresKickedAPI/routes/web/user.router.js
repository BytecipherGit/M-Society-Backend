module.exports = (app) => {
  const user = require("../../controllers/web/user.controller");
  const validateuser = require("../../middleware/validateToken");

  let router = require("express").Router();

  /**
   * @swagger
   * /api/web/singup:
   *   post:
   *     summary: adding a new user
   *     tags:
   *       - user
   *     security:
   *       - apiKeyAuth: []
   *     parameters:
   *       - in: body
   *         description: add a new user in the database
   *         schema:
   *           type: object
   *           required:
   *             - name
   *             - phone
   *             - loginId
   *             - password
   *           properties:
   *             name:
   *               type: string
   *             phone:
   *               type: string
   *             loginId:
   *               type: string
   *             password:
   *               type: string
   *     responses:
   *       200:
   *         description:  user added successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 data:
   *                   type: array
   *                   items:
   *                     type: object
   *                     properties:
   *                       phone:
   *                         type: string
   *                         example: 9519018155
   *                       password:
   *                         type: string
   *                         example:  1234
   */

  router.post("/singup", user.singup);

  /**
   * @swagger
   * /api/web/verifyOTP:
   *   post:
   *     summary: verify the OTP
   *     tags:
   *       - user
   *     security:
   *       - apiKeyAuth: []
   *     parameters:
   *       - in: body
   *         description: verifying otp by providing email and otp
   *         schema:
   *           type: object
   *           required:
   *             - email
   *             - otp
   *           properties:
   *             email:
   *               type: string
   *             otp:
   *               type: string
   *     responses:
   *       200:
   *         description:  otp verified successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 data:
   *                   type: array
   *                   items:
   *                     type: object
   *                     properties:
   *                       email:
   *                         type: string
   *                         example: 9519018155
   *                       password:
   *                         type: string
   *                         example:  1234
   */
  router.post("/verifyOTP", user.verifyOTP);
  /**
   * @swagger
   * /api/web/login:
   *   post:
   *     summary: login user
   *     tags:
   *       - user
   *     security:
   *       - apiKeyAuth: []
   *     parameters:
   *       - in: body
   *         description: login user with loginid &password
   *         schema:
   *           type: object
   *           required:
   *             - loginId
   *             - password
   *           properties:
   *             loginId:
   *               type: string
   *               description: use phone or loginid
   *             password:
   *               type: string
   *     responses:
   *       200:
   *         description: login successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 data:
   *                   type: array
   *                   items:
   *                     type: object
   *                     properties:
   *                       loginId:
   *                         type: string
   *                         example: 1
   *                       password:
   *                         type: string
   *                         example:  1234
   */

  router.post("/login", user.login);

  /**
   * @swagger
   * /api/web/setNewPassword:
   *   put:
   *     summary: set a new password for user
   *     tags:
   *       - user
   *     security:
   *       - apiKeyAuth: []
   *     parameters:
   *       - in: body
   *         description: set new password for user using email otp and password
   *         schema:
   *           type: object
   *           required:
   *             - email
   *             - otp
   *             - password
   *           properties:
   *             email:
   *               type: string
   *               description: use email or loginid
   *             password:
   *               type: string
   *             otp:
   *               type: string
   *     responses:
   *       200:
   *         description: password changed successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 data:
   *                   type: array
   *                   items:
   *                     type: object
   *                     properties:
   *                       email:
   *                         type: string
   *                         example: dmdmishra692@gmail.com
   *                       password:
   *                         type: string
   *                         example:  12345
   */

  router.put("/setNewPassword", user.setNewPassword);

  /**
   * @swagger
   * /api/web/sendOTP:
   *   post:
   *     summary: send otp over users email
   *     tags:
   *       - user
   *     security:
   *       - apiKeyAuth: []
   *     parameters:
   *       - in: body
   *         description: send otp over email
   *         schema:
   *           type: object
   *           required:
   *             - email
   *           properties:
   *             email:
   *               type: string
   *     responses:
   *       200:
   *         description: otp send successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 data:
   *                   type: array
   *                   items:
   *                     type: object
   *                     properties:
   *                       otp:
   *                         type: string
   *                         example: 1234
   */
  router.post("/sendOTP", user.sendOTP);

  router.put(
    "/changePassword",
    validateuser.validateToken,
    user.changePassword
  );
  router.get("/getProfile", validateuser.validateToken, user.getProfile);
  router.put("/updateProfile", validateuser.validateToken, user.updateProfile);
  router.post("/logout", validateuser.validateToken, user.logout);

  app.use("/api/web", router);
};
