module.exports = app => {
    const user = require("../controllers/inspection.controller");

    let router = require("express").Router();

    router.post("/createInspection", user.createinspection);

    app.use("/api/inspection", router);
}