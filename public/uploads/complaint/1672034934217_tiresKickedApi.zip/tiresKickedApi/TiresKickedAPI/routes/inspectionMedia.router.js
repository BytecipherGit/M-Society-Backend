module.exports = (app) => {
  const InspectionMedia = require("../controllers/inspectionMedia.controller");

  let router = require("express").Router();

  router.post("/submitInspectionMedia", InspectionMedia.createInspectionMedia);

  router.get("/getInspectionMedia/:inspectionId", InspectionMedia.get);

  router.put("/updateSubmitMediaInspection", InspectionMedia.updateMedia);

  router.get(
    "/getAllInspectionMedias/:page",
    InspectionMedia.getAllInspectionMedia
  );

  router.get("/getAllInspections/:page", InspectionMedia.getAllInspections);

  app.use("/api/inspectionMedia", router);
};
